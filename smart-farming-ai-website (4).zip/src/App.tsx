import { useState } from 'react';

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home', icon: '🏠' },
    { id: 'problem', label: 'Challenge', icon: '⚠️' },
    { id: 'solution', label: 'Solution', icon: '💡' },
    { id: 'tech', label: 'Technology', icon: '🔧' },
    { id: 'features', label: 'Features', icon: '✨' },
    { id: 'opensource', label: 'Open Source', icon: '🤖' },
    { id: 'guide', label: 'Setup Guide', icon: '📋' },
    { id: 'deploy', label: 'Deploy', icon: '🚀' },
  ];

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 via-white to-amber-50">
      {/* Mobile Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-lg border-b border-emerald-100 shadow-sm">
        <div className="flex justify-between items-center h-14 px-4">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-green-600 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <span className="text-lg font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
              AgriAI
            </span>
          </div>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg bg-emerald-50 text-emerald-600"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {mobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="absolute top-14 left-0 right-0 bg-white border-b border-emerald-100 shadow-lg animate-fadeIn">
            <div className="p-2 max-h-96 overflow-y-auto">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-gray-600 hover:bg-gray-50"
                >
                  <span className="text-xl">{item.icon}</span>
                  <span className="font-medium">{item.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Main Content - Single Scrollable Page */}
      <main>
        {/* Hero Section */}
        <section id="home" className="relative overflow-hidden min-h-screen flex items-center">
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-100 via-green-50 to-amber-100">
            <div className="absolute inset-0 opacity-30">
              <div className="absolute top-20 left-10 w-48 h-48 bg-emerald-300 rounded-full mix-blend-multiply filter blur-3xl animate-pulse"></div>
              <div className="absolute top-40 right-10 w-48 h-48 bg-green-300 rounded-full mix-blend-multiply filter blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
              <div className="absolute bottom-20 left-1/2 w-48 h-48 bg-amber-300 rounded-full mix-blend-multiply filter blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
            </div>
          </div>

          <div className="relative px-4 py-20 w-full">
            <div className="max-w-lg mx-auto text-center">
              <div className="inline-flex items-center space-x-2 bg-emerald-100 border border-emerald-200 rounded-full px-3 py-1.5 mb-6">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                <span className="text-emerald-700 text-xs font-medium">Empowering Rural Farmers with AI</span>
              </div>

              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 leading-tight">
                Smart Farming with
                <span className="block bg-gradient-to-r from-emerald-600 via-green-600 to-amber-600 bg-clip-text text-transparent">
                  AI Agents
                </span>
              </h1>

              <p className="text-sm md:text-base text-gray-600 mb-6 leading-relaxed">
                Deploy ESP32 & Raspberry Pi with local AI agents to monitor crops, detect diseases, and automate irrigation—<span className="font-semibold text-emerald-600">even without internet</span>.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 justify-center items-center mb-10">
                <a
                  href="#github"
                  className="inline-flex items-center justify-center space-x-2 bg-gradient-to-r from-emerald-600 to-green-600 text-white px-6 py-3 rounded-xl font-semibold shadow-lg shadow-emerald-200 hover:shadow-xl hover:scale-105 transition-all w-full sm:w-auto"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/>
                  </svg>
                  <span>GitHub</span>
                </a>
                <a
                  href="#guide"
                  onClick={(e) => { e.preventDefault(); scrollToSection('guide'); }}
                  className="inline-flex items-center justify-center space-x-2 bg-white border-2 border-emerald-600 text-emerald-600 px-6 py-3 rounded-xl font-semibold hover:bg-emerald-50 transition-all w-full sm:w-auto"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                  <span>Guide</span>
                </a>
              </div>

              <div className="grid grid-cols-2 gap-3 max-w-lg mx-auto">
                {[
                  { value: '100%', label: 'Offline' },
                  { value: '24/7', label: 'Monitoring' },
                  { value: '30+', label: 'Diseases' },
                  { value: '$0', label: 'Software' },
                ].map((stat, idx) => (
                  <div key={idx} className="bg-white/90 backdrop-blur rounded-xl p-4 shadow-lg border border-emerald-100">
                    <div className="text-2xl font-bold text-emerald-600">{stat.value}</div>
                    <div className="text-gray-600 text-xs">{stat.label}</div>
                  </div>
                ))}
              </div>

              <div className="mt-8 animate-bounce">
                <svg onClick={() => scrollToSection('problem')} className="w-8 h-8 text-emerald-600 mx-auto cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                </svg>
              </div>
            </div>
          </div>
        </section>

        {/* Problem Section */}
        <section id="problem" className="py-16 px-4 bg-white">
          <div className="max-w-lg mx-auto">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">The Challenge</h2>
              <p className="text-sm text-gray-600">Barriers farmers face with modern technology</p>
            </div>

            <div className="space-y-4">
              {[
                { icon: '📡', title: 'No Internet', description: 'Rural farmlands lack reliable internet, making cloud AI inaccessible.', color: 'red' },
                { icon: '🦠', title: 'Late Detection', description: 'Crop diseases detected too late, causing significant yield losses.', color: 'orange' },
                { icon: '💧', title: 'Water Waste', description: 'Traditional irrigation wastes water without adapting to soil needs.', color: 'blue' },
                { icon: '🗣️', title: 'Language Barriers', description: 'Most AI tools in English, leaving local farmers unable to benefit.', color: 'purple' },
              ].map((challenge, idx) => (
                <div key={idx} className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-4 shadow border border-gray-100">
                  <div className="flex items-start space-x-4">
                    <div className={`w-12 h-12 rounded-xl bg-${challenge.color}-100 flex items-center justify-center text-2xl flex-shrink-0`}>
                      {challenge.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-900 mb-1">{challenge.title}</h3>
                      <p className="text-sm text-gray-600">{challenge.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 bg-gradient-to-r from-red-50 via-orange-50 to-amber-50 rounded-2xl p-6">
              <h3 className="font-bold text-gray-900 mb-4 text-center">Global Impact</h3>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-red-600">40%</div>
                  <div className="text-xs text-gray-600">Crop Loss</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-orange-600">30%</div>
                  <div className="text-xs text-gray-600">Water Waste</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-amber-600">2B+</div>
                  <div className="text-xs text-gray-600">No Internet</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Solution Section */}
        <section id="solution" className="py-16 px-4 bg-gradient-to-br from-emerald-50 via-white to-green-50">
          <div className="max-w-lg mx-auto">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">How It Works</h2>
              <p className="text-sm text-gray-600">Complete AI-powered farming system</p>
            </div>

            <div className="space-y-4">
              {[
                { step: '01', title: 'Hardware', description: 'Install ESP32 sensors & Pi cameras', icon: '🔧' },
                { step: '02', title: 'AI Models', description: 'Run fine-tuned models locally', icon: '🤖' },
                { step: '03', title: 'AI Agents', description: 'PicoClaw & Hermes coordinate', icon: '🧠' },
                { step: '04', title: 'Irrigation', description: 'Auto water based on soil needs', icon: '💧' },
                { step: '05', title: 'Detection', description: 'AI identifies crop diseases', icon: '🌿' },
                { step: '06', title: 'NLP', description: 'Talk to AI in local language', icon: '💬' },
              ].map((solution, idx) => (
                <div key={idx} className="bg-white rounded-xl p-4 shadow-lg border border-emerald-100">
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-green-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                      {solution.step}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="text-xl">{solution.icon}</span>
                        <h3 className="font-bold text-gray-900">{solution.title}</h3>
                      </div>
                      <p className="text-sm text-gray-600">{solution.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 bg-white rounded-xl p-4 shadow border border-emerald-100">
              <h3 className="font-bold text-gray-900 mb-3 text-center text-sm">System Flow</h3>
              <div className="flex flex-wrap justify-center items-center gap-2">
                <div className="bg-blue-100 rounded-lg px-3 py-2 text-center">
                  <div className="font-bold text-blue-800 text-xs">ESP32</div>
                  <div className="text-[10px] text-blue-600">Sensors</div>
                </div>
                <span className="text-gray-400">→</span>
                <div className="bg-purple-100 rounded-lg px-3 py-2 text-center">
                  <div className="font-bold text-purple-800 text-xs">Raspberry Pi</div>
                  <div className="text-[10px] text-purple-600">AI</div>
                </div>
                <span className="text-gray-400">→</span>
                <div className="bg-emerald-100 rounded-lg px-3 py-2 text-center">
                  <div className="font-bold text-emerald-800 text-xs">AI Agents</div>
                  <div className="text-[10px] text-emerald-600">Control</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Technology Section */}
        <section id="tech" className="py-16 px-4 bg-white">
          <div className="max-w-lg mx-auto">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Technology</h2>
              <p className="text-sm text-gray-600">Open-source stack for accessibility</p>
            </div>

            <div className="space-y-6">
              {[
                {
                  title: 'Microcontrollers',
                  icon: '🔌',
                  items: [{ name: 'ESP32', desc: 'WiFi + BT controller' }, { name: 'Raspberry Pi', desc: 'AI processing' }, { name: 'Arduino', desc: 'Simple sensors' }],
                },
                {
                  title: 'AI Agents',
                  icon: '🤖',
                  items: [{ name: 'PicoClaw', desc: 'Edge AI agent' }, { name: 'ZeroClaw', desc: 'Zero-shot learning' }, { name: 'Hermes', desc: 'Multi-agent system' }],
                },
                {
                  title: 'AI Models',
                  icon: '🧠',
                  items: [{ name: 'MobileNet', desc: 'Lightweight CNN' }, { name: 'TinyBERT', desc: 'Local language NLP' }, { name: 'YOLO Nano', desc: 'Real-time detection' }],
                },
                {
                  title: 'Sensors',
                  icon: '📊',
                  items: [{ name: 'Soil Moisture', desc: 'Capacitive sensor' }, { name: 'DHT22', desc: 'Temp & humidity' }, { name: 'NPK Sensor', desc: 'Nutrient detection' }],
                },
              ].map((category, idx) => (
                <div key={idx}>
                  <div className="flex items-center space-x-2 mb-3">
                    <span className="text-xl">{category.icon}</span>
                    <h3 className="font-bold text-gray-900">{category.title}</h3>
                  </div>
                  <div className="space-y-2">
                    {category.items.map((item, itemIdx) => (
                      <div key={itemIdx} className="bg-gradient-to-br from-gray-50 to-white rounded-lg p-3 border border-gray-200">
                        <div className="font-semibold text-gray-900 text-sm">{item.name}</div>
                        <div className="text-xs text-gray-600">{item.desc}</div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-16 px-4 bg-gradient-to-br from-emerald-50 via-white to-amber-50">
          <div className="max-w-lg mx-auto">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Features</h2>
              <p className="text-sm text-gray-600">Everything you need for smart farming</p>
            </div>

            <div className="space-y-3">
              {[
                { title: 'Soil Monitoring', description: 'Real-time moisture, temperature, pH tracking', icon: '📊', color: 'from-blue-500 to-cyan-500' },
                { title: 'Auto Irrigation', description: 'Smart water based on crop needs', icon: '💧', color: 'from-cyan-500 to-blue-500' },
                { title: 'Disease Detection', description: 'AI identifies 30+ crop diseases', icon: '🔍', color: 'from-green-500 to-emerald-500' },
                { title: 'Voice Interface', description: 'Talk to AI in local language', icon: '🎤', color: 'from-purple-500 to-pink-500' },
                { title: 'Offline Mode', description: 'Full functionality without internet', icon: '📴', color: 'from-amber-500 to-orange-500' },
                { title: 'Multi-Crop', description: 'Rice, wheat, maize, vegetables & more', icon: '🌾', color: 'from-red-500 to-pink-500' },
              ].map((feature, idx) => (
                <div key={idx} className="bg-white rounded-xl p-4 shadow-lg border border-gray-100">
                  <div className="flex items-start space-x-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center text-white text-2xl flex-shrink-0`}>
                      {feature.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-900 mb-1">{feature.title}</h3>
                      <p className="text-sm text-gray-600">{feature.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 bg-white rounded-xl p-4 shadow border border-emerald-100">
              <h3 className="font-bold text-gray-900 mb-3 text-sm">Detectable Diseases</h3>
              <div className="flex flex-wrap gap-2">
                {['Leaf Blight', 'Rust', 'Mildew', 'Spot', 'Wilt', 'Rot', 'Curl', 'Virus'].map((disease, idx) => (
                  <span key={idx} className="bg-red-50 text-red-700 px-3 py-1 rounded-full text-xs border border-red-200">
                    {disease}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Open Source Section */}
        <section id="opensource" className="py-16 px-4 bg-white">
          <div className="max-w-lg mx-auto">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Open Source</h2>
              <p className="text-sm text-gray-600">Free to use, modify & distribute</p>
            </div>

            <div className="space-y-3">
              {[
                { name: 'PicoClaw', desc: 'Lightweight AI for edge devices', stars: '2.4k', license: 'MIT', url: '#' },
                { name: 'ZeroClaw', desc: 'Zero-shot disease detection', stars: '1.8k', license: 'Apache', url: '#' },
                { name: 'OpenClaw', desc: 'Agricultural AI framework', stars: '3.2k', license: 'GPL v3', url: '#' },
                { name: 'Hermes', desc: 'Multi-agent coordination', stars: '1.5k', license: 'MIT', url: '#' },
                { name: 'AgriVision', desc: '50k+ crop disease images', stars: '4.1k', license: 'CC BY', url: '#' },
                { name: 'SmartIrrigate', desc: 'ESP32 irrigation system', stars: '2.9k', license: 'MIT', url: '#' },
              ].map((project, idx) => (
                <a key={idx} href={project.url} className="block bg-gradient-to-br from-gray-50 to-white rounded-xl p-4 border border-gray-200 hover:border-purple-300">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-white font-bold text-sm">
                        {project.name[0]}
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900">{project.name}</h4>
                        <div className="flex items-center space-x-2 text-xs text-gray-500">
                          <span>⭐ {project.stars}</span>
                          <span>•</span>
                          <span>{project.license}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600">{project.desc}</p>
                </a>
              ))}
            </div>

            <div className="mt-6 bg-gradient-to-r from-purple-50 via-pink-50 to-rose-50 rounded-xl p-4">
              <h3 className="font-bold text-gray-900 mb-3 text-center text-sm">Community</h3>
              <div className="grid grid-cols-4 gap-2 text-center">
                <div>
                  <div className="text-lg font-bold text-purple-600">15k+</div>
                  <div className="text-[10px] text-gray-600">Stars</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-purple-600">500+</div>
                  <div className="text-[10px] text-gray-600">Contributors</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-purple-600">50+</div>
                  <div className="text-[10px] text-gray-600">Countries</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-purple-600">10k+</div>
                  <div className="text-[10px] text-gray-600">Deployments</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Setup Guide Section */}
        <section id="guide" className="py-16 px-4 bg-gradient-to-br from-amber-50 via-white to-emerald-50">
          <div className="max-w-lg mx-auto">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Setup Guide</h2>
              <p className="text-sm text-gray-600">6 steps to deploy your system</p>
            </div>

            <div className="space-y-4">
              {[
                { number: '1', title: 'Gather Hardware', items: ['ESP32 boards', 'Raspberry Pi 4', 'Soil sensors', 'Camera module', 'Water pump', 'Solenoid valves'], color: 'blue' },
                { number: '2', title: 'Connect Hardware', items: ['Wire sensors to ESP32', 'Connect camera to Pi', 'Setup water pumps', 'Power distribution'], color: 'green' },
                { number: '3', title: 'Install Software', items: ['Raspberry Pi OS', 'MicroPython firmware', 'Python dependencies', 'TensorFlow Lite'], color: 'purple' },
                { number: '4', title: 'Deploy AI Models', items: ['Download MobileNet', 'Fine-tune on crops', 'Convert to TFLite', 'Test accuracy'], color: 'amber' },
                { number: '5', title: 'Configure Agents', items: ['Install PicoClaw', 'Setup sensor agent', 'Configure irrigation', 'Test communication'], color: 'red' },
                { number: '6', title: 'Field Test', items: ['Test sensors', 'Verify detection', 'Test irrigation', 'Deploy to field'], color: 'emerald' },
              ].map((step, idx) => (
                <div key={idx} className="bg-white rounded-xl p-4 shadow-lg border border-gray-100">
                  <div className="flex items-start space-x-4">
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br from-${step.color}-500 to-${step.color}-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0`}>
                      {step.number}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-900 mb-2">{step.title}</h3>
                      <div className="space-y-1">
                        {step.items.map((item, itemIdx) => (
                          <div key={itemIdx} className="flex items-center space-x-2">
                            <div className={`w-4 h-4 rounded-full bg-${step.color}-100 flex items-center justify-center flex-shrink-0`}>
                              <svg className={`w-2.5 h-2.5 text-${step.color}-600`} fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                              </svg>
                            </div>
                            <span className="text-xs text-gray-700">{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 bg-gray-900 rounded-xl p-4 overflow-hidden">
              <div className="flex items-center space-x-2 mb-3">
                <div className="w-2.5 h-2.5 bg-red-500 rounded-full"></div>
                <div className="w-2.5 h-2.5 bg-yellow-500 rounded-full"></div>
                <div className="w-2.5 h-2.5 bg-green-500 rounded-full"></div>
                <span className="text-gray-400 text-xs ml-2">main.py</span>
              </div>
              <pre className="text-xs text-gray-300 overflow-x-auto">
                <code>{`class SmartFarm:
    def __init__(self):
        self.agent = PicoClaw()
        self.disease = Detector()
        self.irrigation = System()
    
    def run(self):
        moisture = self.agent.read()
        if moisture < threshold:
            self.irrigation.on()
        img = self.agent.capture()
        disease = self.disease.predict(img)`}</code>
              </pre>
            </div>
          </div>
        </section>

        {/* Deploy Section */}
        <section id="deploy" className="py-16 px-4 bg-white">
          <div className="max-w-lg mx-auto">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Deploy</h2>
              <p className="text-sm text-gray-600">QR code & GitHub deployment</p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 rounded-2xl p-6 mb-6">
              <h3 className="font-bold text-gray-900 mb-4">QR Code Access</h3>
              <div className="bg-white rounded-xl p-4 mb-4">
                <div className="w-full aspect-square bg-gradient-to-br from-emerald-500 to-green-600 rounded-lg flex items-center justify-center mb-3">
                  <div className="bg-white p-3 rounded-lg">
                    <div className="w-32 h-32 bg-gray-900 rounded"></div>
                  </div>
                </div>
                <p className="text-gray-600 text-sm text-center mb-3">Scan to access dashboard</p>
                <div className="flex space-x-2">
                  <button className="flex-1 bg-emerald-600 text-white px-4 py-2.5 rounded-lg font-semibold text-sm">
                    Download
                  </button>
                  <button className="flex-1 bg-white border-2 border-emerald-600 text-emerald-600 px-4 py-2.5 rounded-lg font-semibold text-sm">
                    Customize
                  </button>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900 text-sm">Offline Access</div>
                    <div className="text-xs text-gray-600">No internet needed</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900 text-sm">Mobile Friendly</div>
                    <div className="text-xs text-gray-600">Works on any phone</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-6 text-white">
              <div className="flex items-center space-x-3 mb-4">
                <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/>
                </svg>
                <div>
                  <h3 className="font-bold text-lg">GitHub Deployment</h3>
                  <p className="text-gray-400 text-xs">Free hosting</p>
                </div>
              </div>
              <ol className="space-y-3 mb-4">
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 font-bold text-xs">1</div>
                  <div>
                    <div className="font-semibold text-sm">Fork Repository</div>
                    <div className="text-gray-400 text-xs">Click fork on GitHub</div>
                  </div>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 font-bold text-xs">2</div>
                  <div>
                    <div className="font-semibold text-sm">Enable Pages</div>
                    <div className="text-gray-400 text-xs">Settings → Pages</div>
                  </div>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 font-bold text-xs">3</div>
                  <div>
                    <div className="font-semibold text-sm">Customize</div>
                    <div className="text-gray-400 text-xs">Update config.json</div>
                  </div>
                </li>
              </ol>
              <a href="#" className="block text-center bg-white text-gray-900 px-4 py-3 rounded-xl font-semibold text-sm">
                View Repository
              </a>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-4">
        <div className="max-w-md mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-green-600 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <span className="text-lg font-bold">AgriAI</span>
          </div>
          <p className="text-gray-400 text-xs mb-4">
            Empowering rural farmers with AI technology.
          </p>
          <div className="flex justify-center space-x-4 mb-4">
            <a href="#" className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-emerald-600 transition-colors">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/>
              </svg>
            </a>
            <a href="#" className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-emerald-600 transition-colors">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
              </svg>
            </a>
          </div>
          <p className="text-gray-500 text-xs">
            © 2024 AgriAI. MIT License.
          </p>
        </div>
      </footer>
    </div>
  );
}
